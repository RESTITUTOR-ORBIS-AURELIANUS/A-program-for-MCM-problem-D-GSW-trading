public class player {
    String name;
    double A_T;
    double WS;
    double _3p;
    double Ss;
    public int salary;
    public int fans;
    public double dPe;
    double pIr;
    double Ir;
    int age;
    player(String oname,double oA_T,double oWS,double o_3p,double oSs,int osalary,int ofans,double opIr,int oage){
        name=oname;
        A_T=oA_T;
        WS=oWS;
        _3p=o_3p;
        Ss=oSs;
        salary=osalary;
        fans=ofans;
        pIr=opIr;
        age=oage;
        dPe=-0.58024+0.47267*WS+0.23633*WS*Ss+0.67623*WS*_3p+0.01185*WS*A_T;
        dPe*=1.5;
        //dPe*=dPe;
        //Ir=pIr*min(1,1-(age-32))*max(1,age-32);
        Ir=pIr;
        dPe*=Ir;
    }

}
