public class probability {
    public String player1;
    public String player2;
    public String player3;
    public double V;
    public double J;
    public double Pe;
    public double Po;
    public double S;
    public double P;
    public double O;
    probability(String p1,String p2,String p3,double v,double j,double pe,double po,double s,double o,double p){
        player1=p1;
        player2=p2;
        player3=p3;
        V=v;
        J=j;
        Pe=pe;
        Po=po;
        S=s;
        P=p;
        O=o;
    }
}
