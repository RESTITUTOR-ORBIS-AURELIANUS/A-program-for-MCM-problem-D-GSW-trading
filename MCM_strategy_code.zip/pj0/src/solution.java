import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static java.lang.Math.exp;
import static java.lang.Math.pow;

public class solution {
    static double m = 1000000;
    List<player> FreeAgents= new ArrayList<>();
    List<probability> allProbability=new ArrayList<>();
    //```````````````
    double base=10.93385e8;
    double a=2.1788;
    double b=2.2411;
    double c=1.0379e8;
    double k=49.9754;
    double delta;
    //```````````````
    double w1=1;
    double w2=1;
    double w3=1;
    //```````````````value para
    double prev_v;
    //```````````````interest
    double interest=0;
    //```````````````
    String ans_player1,ans_player2,ans_player3;
    double ans_J=-10000000;
    //```````````````
    double other_revenue=2*m;
    //```````````````price para
    double r1=1.05;
    double r2=1.05;
    double pl=18000*100*0.5;
    double lambda=1;
    double epsilon=381;
    double gamma=3;
    double k1=9, k2=100, k3=0;
    //```````````````
    double other_expense=180*m;
    double tax_line=201690000;


    static void main(String[] args) {
        solution this_solution=new solution();
        this_solution.initialize();
        this_solution.tool();
//        System.out.println(this_solution.ans_J);
//        System.out.println(this_solution.ans_player1);
//        System.out.println(this_solution.ans_player2);
//        System.out.println(this_solution.ans_player3);
        this_solution.allProbability.sort(Comparator.comparingDouble((probability p) -> p.J).reversed());
        for(int i=0;i<this_solution.allProbability.size();i++){
            probability thisp=this_solution.allProbability.get(i);
            System.out.println(thisp.player1+" "+thisp.player2+" "+thisp.player3+" "+thisp.V+" "+thisp.J+" "+thisp.Pe+" "+thisp.Po+" "+thisp.S+" "+thisp.O+" "+thisp.P);
        }
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        for(int i=0;i<this_solution.FreeAgents.size();i++){
            player thisplayer=this_solution.FreeAgents.get(i);
            System.out.println(thisplayer.name+" "+thisplayer.dPe);
        }
    }
    public void tool(){
        double oPe=44;
        oPe-=(6.0+0.3+0.2+5.3+1.2-1.0);
        int oPo=75257000;
        double oS =192778341;
        int l=FreeAgents.size();
        int num1=0,num2=1,num3=2;
        for(num1=0;num1<l-2;num1++){
            for(num2=num1+1;num2<l-1;num2++){
                for(num3=num2+1;num3<l;num3++){
                    player first=FreeAgents.get(num1);
                    player second=FreeAgents.get(num2);
                    player third=FreeAgents.get(num3);
                    //double cur_Pe=cal_real_PE(oPe, first.dPe+ second.dPe+ third.dPe);
                    double cur_Pe=oPe+first.dPe+ second.dPe+ third.dPe;
                    int cur_Po=oPo+ first.fans+ second.fans+ third.fans;
                    double cur_R=calculateR(cur_Pe,cur_Po);
                    double cur_S = oS+first.salary+ second.salary+ third.salary;
                    double cur_O=calculateO(cur_S);
                    double cur_P=calculateP(cur_R,cur_O);
                    double cur_V=calculate_value(cur_P,cur_Pe,cur_Po);
                    double cur_J=calculateJ(cur_V,cur_P,cur_Pe);
//                    if(ans_J<cur_J){
//                        ans_J=cur_J;
//                        ans_player1= first.name;
//                        ans_player2= second.name;
//                        ans_player3= third.name;
//                    }
                    allProbability.add(new probability(first.name, second.name, third.name, cur_V,cur_J,cur_Pe,cur_Po,cur_S,cur_O,cur_P));
                }
            }
        }
    }
    public double calculate_value(double P,double Pe,double PO){
        double value;
        value = a * P + b * PO + c / (1 + exp(k * (somefuncR(Pe)-16)))+base;
        return value;
    }
    private double somefuncR(double Pe){
        double rank;
        rank = 30 * (1 - Tool.calculateCDF(Pe,41,12));
        return rank;
    }
    private double calculateJ(double value,double P,double Pe){
        return (w1 * value + w2 * P + w3 * Pe);
    }
    private double calculateR(double Pe, int Po){
        double pr = lambda * pl + epsilon * pow(Pe, r1) * pow(Po/(1.8*m), r2);
        double fan_revenue = k1 * Po + k2 * pl + k3 * pl * Po;
        double local_revenue = 41 * pr + gamma * pr * playoff_games(Pe) + fan_revenue;
        return (local_revenue + other_revenue);
    }
    private double calculate_tax(double salary){
        double ex = salary - tax_line;
        if(ex <= 0){
            return 0;
        }
        else if(ex <= 5 * m){
            return 1.5 * ex;
        }
        else if(ex <= 10 * m){
            return 7.5 * m + 1.75 * (ex - 5*m);
        }
        else if(ex <= 15 * m){
            return 16.25 * m + 2.5 * (ex - 10 * m);
        }
        else if(ex <= 20 * m){
            return 28.75 * m + 3.25 * (ex - 15 * m);
        }
        else{
            double index = (ex - 20 * m)/(5 * m);
            int Index = (int) index;
            return 45 * m + (3.75 + 0.5 * Index) * (ex - 20 * m);
        }
    }
    private double calculateO(double salary){
        return salary + calculate_tax(salary) + other_expense;
    }
    private double playoff_games(double Pe){
        double rank = somefuncR(Pe);
        int Rank = (int) rank;
        if(Rank > 16){
            return 0;
        }
        else if(Rank >= 9){
            return 3;
        }
        else if(Rank >= 5){
            return 6;
        }
        else if(Rank >= 3){
            return 9;
        }
        else{
            return 12;
        }
    }
    private double cal_real_PE(double PE, double newPE){
        if(PE + newPE <= 50){
            return PE + newPE;
        }
        else if(PE + newPE <= 60){
            return 50 + 0.2 * (PE + newPE - 50);
        }
        else if(PE + newPE <- 70){
            return 60 + 0.05 * (PE + newPE - 60);
        }
        else{
            return 70 + 0.01 * (PE + newPE - 70);
        }
    }
    private double calculateP(double R, double O){
        return (R - O - interest);
    }
    private void initialize(){
        FreeAgents.add(new player("TraeYoung",2.5,5.5,0.305,0.303,35000000,5000000,0.927,27));
        FreeAgents.add(new player("ZachLavine", 1.5, 5.1, 0.397, 0.624, 39000000, 2248824, 0.902, 30));
        //FreeAgents.add(new player("Tangzitong", 0.1, 0.5, 0.05, 0.080, 20000, 69, 1.0, 19));
        FreeAgents.add(new player("JamesHarden", 2.0, 8.3, 0.362, 0.596, 42000000, 12000000, 0.963, 36));
        FreeAgents.add(new player("CJMcCollum", 2.1, 1.5, 0.384, 0.350, 30000000, 1000000, 0.427, 34));
        FreeAgents.add(new player("KhrisMiddleton", 2.7, 2.0, 0.315, 0.785, 25000000, 398000, 0.451, 34));
        FreeAgents.add(new player("KristapsPorzingis", 1.6, 5.3, 0.360, 0.367, 28000000, 2000000, 0.512, 30));
        FreeAgents.add(new player("AndrewWiggins", 2.9, 5.9, 0.415, 0.956, 28000000, 2000000, 0.932, 30));
        FreeAgents.add(new player("FredVanfleet", 3.8, 5.3, 0.371, 0.342, 25000000, 632000, 0.732, 31));
        FreeAgents.add(new player("JohnCollins", 0.8, 2.8, 0.426, 0.833, 25000000, 184000, 0.537, 28));
        FreeAgents.add(new player("Bogdan", 2.0, 1.9, 0.427, 0.573, 16000000, 841000, 0.659, 33));
        FreeAgents.add(new player("BrookLopez", 1.7, 6.5, 0.373, 0.569, 8781000, 890000, 0.976, 37));
        FreeAgents.add(new player("KevonLooney", 3.1, 4.3, 0.111, 0.803, 5685000, 433000, 0.927, 29));
        FreeAgents.add(new player("DeAnthonyMelton", 2.3, 5.7, 0.412, 0.844, 8781000, 122000, 0.800, 27));
        FreeAgents.add(new player("GaryPaytonII", 2.6, 3.2, 0.33, 0.497, 2667947, 130000, 0.920, 35));
        FreeAgents.add(new player("examplePlayer1", 1.2, 0.5, 0.25, 0.500,2000000, 20000, 0.800, 28));
        FreeAgents.add(new player("examplePlayer2", 1.2, 0.5, 0.25, 0.500,2000000, 20000, 0.800, 28));
    }
}
