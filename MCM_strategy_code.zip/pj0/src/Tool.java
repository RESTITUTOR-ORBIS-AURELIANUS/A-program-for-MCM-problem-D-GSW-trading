public class Tool {
    private static double erfBasic(double x) {
        if (x == 0) return 0;
        if (x < 0) return -erfBasic(-x); // 利用奇函数性质

        int n = 10000; // 积分分段数，值越大精度越高
        double h = x / n; // 步长
        double sum = 0.5 * Math.exp(-x * x); // 末项

        // 梯形法则数值积分
        for (int i = 0; i < n; i++) {
            double t = i * h;
            sum += Math.exp(-t * t);
        }

        return (2.0 / Math.sqrt(Math.PI)) * h * sum;
    }
    public static double calculateCDF(double x, double mean, double stdDev) {
        // 套用数学公式
        return 0.5 * (1 + erfBasic((x - mean) / (stdDev * Math.sqrt(2.0))));
    }
}
